//
//  RatingsTableViewCell.swift
//  HygieneRating
//
//  Created by Mark Stonehouse on 05/03/2018.
//  Copyright © 2018 Mark Stonehouse. All rights reserved.
//

import UIKit

class RatingTableViewCell: UITableViewCell {
    
}
